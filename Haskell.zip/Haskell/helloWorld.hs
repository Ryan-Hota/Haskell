helloWorld :: Bool
helloWorld = True